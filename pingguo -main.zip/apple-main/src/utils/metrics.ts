export const APP_PRIVACY_MODAL_ID = 'ModalAppPrivacy';
export const CUSTOMER_REVIEW_MODAL_ID = 'ModalCustomerReview';
export const VERSION_HISTORY_MODAL_ID = 'ModalVersionHistory';
export const LICENSE_AGREEMENT_MODAL_ID = 'LicenseAgreement';
